package com.example.menumakanan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class DetailActivity extends AppCompatActivity {

    ImageView detGambar;
    TextView detNama,detHarga,keterangan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        detGambar = findViewById(R.id.detGambar);
        detNama = findViewById(R.id.detNama);
        detHarga = findViewById(R.id.detHarga);
        keterangan = findViewById(R.id.detail);
        
        getIncomingExtra();
    }
    
    private void getIncomingExtra(){
        if(getIntent().hasExtra("gambar") && getIntent().hasExtra("nama") && getIntent().hasExtra("harga") && getIntent().hasExtra("deskripsi")){
            int gambar = getIntent().getIntExtra("gambar", 0);
            String nama = getIntent().getStringExtra("nama");
            String harga = getIntent().getStringExtra("harga");
            String deskripsi = getIntent().getStringExtra("deskripsi");
            
            setDataActivity(gambar, nama, harga, deskripsi);
        }
    }
    
    private void setDataActivity(int gambar, String nama, String harga, String deskripsi){
        Glide.with(this).asBitmap().load(gambar).into(detGambar);
        
        detNama.setText(nama);
        detHarga.setText(harga);
        keterangan.setText(deskripsi);
    }
}