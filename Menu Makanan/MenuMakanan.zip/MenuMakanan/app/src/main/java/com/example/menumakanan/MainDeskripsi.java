package com.example.menumakanan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainDeskripsi extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_deskripsi);

        ImageView gambarDesk = findViewById(R.id.gambarDesk);
        TextView namaDesk = findViewById(R.id.namaDesk);
        TextView hargaDesk = findViewById(R.id.hargaDesk);
        TextView deskripsi = findViewById(R.id.deskripsi);


        Intent intent = getIntent();

        int gambar = intent.getIntExtra("GAMBAR_DEFAULT",0);
        String nama = intent.getStringExtra("JUDUL_DEFAULT");
        int harga = intent.getIntExtra("HARGA_DEFAULT", 0);
        String desk = intent.getStringExtra("KETERANGAN_DEFAULT");


        gambarDesk.setImageResource(gambar);
        namaDesk.setText(nama);
        hargaDesk.setText(harga);
        deskripsi.setText(desk);
    }
}