package com.example.menumakanan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Integer> gambar = new ArrayList<>();
    private ArrayList<String> nama = new ArrayList<>();
    private ArrayList<String> harga = new ArrayList<>();
    private ArrayList<String> deskripsi = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getData();
    }

    private void prosesRecyclerViewAdapter(){
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(gambar, nama, harga, deskripsi,this);

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    private void getData(){
        nama.add("Pecel Lele");
        harga.add("Rp. 15.000");
        gambar.add(R.drawable.pecel_lele);
        deskripsi.add("Lele Goreng dengan Sambal Lalapan");

        nama.add("Nasi Goreng Mercon");
        harga.add("Rp. 14.500");
        gambar.add(R.drawable.nasgor);
        deskripsi.add("Nasi Goreng dengan topping cabai");

        nama.add("Ayam Geprek Keju");
        harga.add("Rp. 20.000");
        gambar.add(R.drawable.ayam);
        deskripsi.add("Ayam yang digeprek dan diberi keju");

        nama.add("Kari Ayam");
        harga.add("Rp. 17.500");
        gambar.add(R.drawable.kari);
        deskripsi.add("Ayam yang dimasak dengan bumbu kari");

        nama.add("Tahu Bulat");
        harga.add("Rp. 500");
        gambar.add(R.drawable.tahu);
        deskripsi.add("Tahu yang berbentuk bulat");

        nama.add("Salad Buah");
        harga.add("Rp. 12.000");
        gambar.add(R.drawable.salad);
        deskripsi.add("Salad dengan isian buah-buahan");

        prosesRecyclerViewAdapter();
    }

}