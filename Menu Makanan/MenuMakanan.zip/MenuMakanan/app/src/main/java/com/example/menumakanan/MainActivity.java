package com.example.menumakanan;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<Makanan>data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyler_view);
        recyclerView.setHasFixedSize(true);



        data = new ArrayList<>();

        for (int i = 0 ; i<MyItem.nama.length;i++){
            data.add(new Makanan(
                    MyItem.nama[i],
                    MyItem.harga[i],
                    MyItem.gambar[i]
            ));
        }
        showlist();
    }

    private void showlist() {
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        AdapterMakanan adapterRecylerViewList = new AdapterMakanan(this,data);
        recyclerView.setAdapter(adapterRecylerViewList);
    }
}