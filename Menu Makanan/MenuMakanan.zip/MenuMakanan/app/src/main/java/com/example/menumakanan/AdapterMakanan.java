package com.example.menumakanan;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterMakanan extends RecyclerView.Adapter<AdapterMakanan.ViewHolder> {

    ArrayList<Makanan> dataItem;

    private final Context context;

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtNama, txtHarga;
        ImageView img_list;
        LinearLayout parentLayoutlist;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtNama = itemView.findViewById(R.id.txtNama);
            txtHarga = itemView.findViewById(R.id.txtHarga);
            img_list    = itemView.findViewById(R.id.img_list);
            parentLayoutlist = itemView.findViewById(R.id.parentLayoutlist);
        }
    }

    AdapterMakanan(Context context,  ArrayList<Makanan> data)  {
        this.context = context;
        this.dataItem = data ;
    }
    @NonNull
    @Override
    public AdapterMakanan.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item,parent,false);
        return new AdapterMakanan.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterMakanan.ViewHolder holder, int position) {


        TextView txtNama = holder.txtNama;
        TextView txtHarga = holder.txtHarga;
        ImageView img_list = holder.img_list;

        txtNama.setText(dataItem.get(position).getNama());
        txtHarga.setText(dataItem.get(position).getHarga());
        img_list.setImageResource(dataItem.get(position).getGambar());

        holder.parentLayoutlist.setOnClickListener(view -> {
            //Toast.makeText(context,dataItem.get(position).getName(), Toast.LENGTH_SHORT).show();

            if(dataItem.get(position).getNama().equals("Pecel Lele")){
                Intent intent = new Intent(context,MainDeskripsi.class);
                intent.putExtra("GAMBAR_DEFAULT",R.drawable.pecel_lele);
                intent.putExtra("JUDUL_DEFAULT","Pecel Lele");
                intent.putExtra("HARGA_DEFAULT", 15000);
                intent.putExtra("KETERANGAN_DEFAULT", "Lele goreng dengan Lalapan dan Sambal");
                context.startActivity(intent);
            }

            if(dataItem.get(position).getNama().equals("Nasi Goreng Mercon")){
                Intent intent = new Intent(context,MainDeskripsi.class);
                intent.putExtra("GAMBAR_DEFAULT",R.drawable.nasgor);
                intent.putExtra("JUDUL_DEFAULT","Nasi Goreng Mercon");
                intent.putExtra("HARGA_DEFAULT", 14500);
                intent.putExtra("KETERANGAN_DEFAULT", "Nasi Goreng pedas yang dimasak dengan cabai");
                context.startActivity(intent);
            }

            if(dataItem.get(position).getNama().equals("Ayam Geprek Keju")){
                Intent intent = new Intent(context,MainDeskripsi.class);
                intent.putExtra("GAMBAR_DEFAULT",R.drawable.ayam);
                intent.putExtra("JUDUL_DEFAULT","Ayam Geprek Keju");
                intent.putExtra("HARGA_DEFAULT", 20000);
                intent.putExtra("KETERANGAN_DEFAULT", "Ayam yang digeprek yang ditambahi keju");
                context.startActivity(intent);
            }

            if(dataItem.get(position).getNama().equals("Kari Ayam")){
                Intent intent = new Intent(context,MainDeskripsi.class);
                intent.putExtra("GAMBAR_DEFAULT",R.drawable.kari);
                intent.putExtra("JUDUL_DEFAULT","Kari Ayam");
                intent.putExtra("HARGA_DEFAULT", 17000);
                intent.putExtra("KETERANGAN_DEFAULT", "Ayam yang dimasak dengan bumbu Kari");
                context.startActivity(intent);
            }

            if(dataItem.get(position).getNama().equals("Tahu Bulat")){
                Intent intent = new Intent(context,MainDeskripsi.class);
                intent.putExtra("GAMBAR_DEFAULT",R.drawable.tahu);
                intent.putExtra("JUDUL_DEFAULT","Tahu Bulat");
                intent.putExtra("HARGA_DEFAULT", 500);
                intent.putExtra("KETERANGAN_DEFAULT", "Seperti Tahu Bulat pada Umumnya");
                context.startActivity(intent);
            }

            if(dataItem.get(position).getNama().equals("Salad Buah")) {
                Intent intent = new Intent(context, MainDeskripsi.class);
                intent.putExtra("GAMBAR_DEFAULT", R.drawable.salad);
                intent.putExtra("JUDUL_DEFAULT", "Salad Buah");
                intent.putExtra("HARGA_DEFAULT", 12000);
                intent.putExtra("KETERANGAN_DEFAULT", "Salad dengan isian aneka macam buah");
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return dataItem.size();
    }


}