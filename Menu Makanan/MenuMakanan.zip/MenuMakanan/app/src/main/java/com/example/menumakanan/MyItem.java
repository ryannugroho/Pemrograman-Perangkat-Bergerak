package com.example.menumakanan;

public class MyItem {

    static int[] gambar = {
            R.drawable.pecel_lele,R.drawable.nasgor,R.drawable.ayam,
            R.drawable.kari,R.drawable.tahu,
            R.drawable.salad
    };

    static String[] nama = {
            "Pecel Lele","Nasi Goreng Mercon","Ayam Geprek Keju",
            "Kari Ayam","Tahu Bulat","Salad Buah"
    };
    static int[] harga = {
            15000, 14500, 20000, 17000, 500, 12000
    };
}
