package com.example.kalkulatorbidangdatar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.example.kalkulatorbidangdatar.MainLingkaran;
import com.example.kalkulatorbidangdatar.MainPersegi;
import com.example.kalkulatorbidangdatar.MainSegitiga;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LinearLayout lingkaran = findViewById(R.id.lingkaran);
        LinearLayout persegi = findViewById(R.id.persegi);
        LinearLayout segitiga = findViewById(R.id.segitiga);

        persegi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MainPersegi.class);
                startActivity(intent);
            }
        });
        lingkaran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MainLingkaran.class);
                startActivity(intent);
            }
        });

        segitiga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MainSegitiga.class);
                startActivity(intent);
            }
        });
    }
}