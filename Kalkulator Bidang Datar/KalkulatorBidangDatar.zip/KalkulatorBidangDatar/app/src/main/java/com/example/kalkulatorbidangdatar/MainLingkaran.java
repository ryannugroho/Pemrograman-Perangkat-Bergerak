package com.example.kalkulatorbidangdatar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainLingkaran extends AppCompatActivity {

    EditText edtJari;
    TextView txtLuas, txtKeliling;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_lingkaran);

        initCompponent();
    }

    private void initCompponent(){
        edtJari = findViewById(R.id.edtJari);
        txtLuas = findViewById(R.id.txtLuas);
        txtKeliling = findViewById(R.id.txtKeliling);
    }

    public void hitungLingkaran(View v){
        int jari = Integer.parseInt(edtJari.getText().toString());
        double luas = Math.PI * Math.pow(jari,2);
        double kllg = 2 * Math.PI * jari;

        txtLuas.setText("Luas Segitiga: "+luas);
        txtKeliling.setText("Keliling Segitiga: "+kllg);
    }
}