package com.example.kalkulatorbidangdatar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainSegitiga extends AppCompatActivity {

    EditText edtAlas, edtTinggi;
    TextView txtLuas, txtKeliling;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_segitiga);

        initCompponent();
    }

    private void initCompponent(){
        edtAlas = findViewById(R.id.edtAlas);
        edtTinggi = findViewById(R.id.edtTinggi);
        txtLuas = findViewById(R.id.txtLuas);
        txtKeliling = findViewById(R.id.txtKeliling);
    }

    public void hitungSegitiga(View v){
        int alas = Integer.parseInt(edtAlas.getText().toString());
        int tinggi = Integer.parseInt(edtTinggi.getText().toString());
        double luas = 0.5 * alas * tinggi;
        int kllg = 3 * alas;

        txtLuas.setText("Luas Segitiga: "+luas);
        txtKeliling.setText("Keliling Segitiga: "+kllg);
    }
}