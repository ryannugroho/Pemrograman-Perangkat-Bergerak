package com.example.kalkulatorbidangdatar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainPersegi extends AppCompatActivity {

    EditText edtPanjang, edtLebar;
    TextView txtLuas, txtKeliling;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_persegi);

        initCompponent();
    }

    private void initCompponent(){
        edtPanjang = findViewById(R.id.edtPanjang);
        edtLebar = findViewById(R.id.edtLebar);
        txtLuas = findViewById(R.id.txtLuas);
        txtKeliling = findViewById(R.id.txtKeliling);
    }

    public void hitungPersegi(View v){
        int panjang = Integer.parseInt(edtPanjang.getText().toString());
        int lebar = Integer.parseInt(edtLebar.getText().toString());
        int luas = panjang * lebar;
        int kllg = 2*(panjang+lebar);

        txtLuas.setText("Luas Persegi: "+luas);
        txtKeliling.setText("Keliling Persegi: "+kllg);
    }
}